# Client Acquisition and Portfolio Management Strategy Project

# 📁 Directory Structure:
# - data/clients.csv
# - data/market_data.csv
# - scripts/client_segmentation.py
# - scripts/risk_profile_matching.py
# - scripts/portfolio_builder.py

# --------- MOCK DATA GENERATION -----------
import pandas as pd
import numpy as np

# Create mock clients.csv
df_clients = pd.DataFrame({
    'client_id': range(1, 6),
    'name': ['Rahul M', 'Ananya S', 'Vikram R', 'Sneha T', 'Amit K'],
    'age': [30, 45, 38, 29, 50],
    'income': [600000, 1200000, 850000, 450000, 1500000],
    'risk_tolerance': ['Medium', 'High', 'Medium', 'Low', 'High'],
    'investment_goal': ['Wealth Accumulation', 'Retirement', 'Education', 'Wealth Accumulation', 'Wealth Protection']
})

# Create mock market_data.csv
df_market = pd.DataFrame({
    'stock': ['TCS', 'HDFC', 'INFY', 'ITC', 'RELIANCE'],
    'sector': ['IT', 'Finance', 'IT', 'FMCG', 'Energy'],
    'volatility': [0.15, 0.08, 0.12, 0.05, 0.20],
    'avg_return': [0.10, 0.07, 0.09, 0.04, 0.12],
    'risk_level': ['Medium', 'Low', 'Medium', 'Low', 'High']
})

# Save to CSV
import os
os.makedirs('data', exist_ok=True)
df_clients.to_csv('data/clients.csv', index=False)
df_market.to_csv('data/market_data.csv', index=False)

# --------- CLIENT SEGMENTATION -----------
def segment_clients():
    clients = pd.read_csv("data/clients.csv")
    segments = clients.groupby("risk_tolerance").size()
    print("\nClient Segmentation by Risk Tolerance:")
    print(segments)

# --------- PORTFOLIO MATCHING -----------
def recommend_portfolio(risk_level, market_data):
    if risk_level == "High":
        return market_data[market_data['risk_level'] != 'Low']
    elif risk_level == "Medium":
        return market_data[market_data['risk_level'] == 'Medium']
    else:
        return market_data[market_data['risk_level'] == 'Low']

# --------- PORTFOLIO BUILDER -----------
def build_portfolio():
    clients = pd.read_csv("data/clients.csv")
    market_data = pd.read_csv("data/market_data.csv")
    os.makedirs("reports", exist_ok=True)

    for _, client in clients.iterrows():
        portfolio = recommend_portfolio(client["risk_tolerance"], market_data)
        portfolio = portfolio.copy()
        portfolio["allocation"] = 1 / len(portfolio)

        writer = pd.ExcelWriter(f"reports/{client['name'].replace(' ', '_')}_portfolio.xlsx")
        portfolio.to_excel(writer, index=False, sheet_name="Portfolio")
        writer.close()
        print(f"Portfolio created for {client['name']} ✅")

# --------- MAIN PIPELINE -----------
if __name__ == '__main__':
    segment_clients()
    build_portfolio()
    print("\n🎯 All portfolios generated in the 'reports/' folder.")
